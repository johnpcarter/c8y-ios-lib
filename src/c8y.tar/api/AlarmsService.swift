//
//  AlarmsService.swift
//  Cumulocity Client Library
//
//
//  Created by John Carter on 21/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_ALARMS_API = "/alarm/alarms"

/**
 Allows alarms to fetched and posted to Cumulocity
 
Refer to the [c8y API documentation](https://cumulocity.com/guides/reference/alarms/) for more information
 */
public class JcAlarmsService: JcConnectionRequest<JcCumulocityConnection> {
    
    /**
     Used when fetching `JcAlarm`s to determines the maximum number allowed in a single request,
     default is 50
     */
    public var pageSize: Int = 50
    
    public var version: String = "1"
    
    /**
     Retrieves the  `JcAlarm` details for the given c8y internal id
  
     - parameter id: c8y generated id
     - parameter pageNum: The page to be fetched, total pages can be found in  via the statistics property `PageStatistics` of the returned `JcPagedAlarms` object
     - parameter completionHandler: the callback to be called with the given `JcAlarm` or error 404 if not found
     - returns: task thread of http request
    */
    public func get(_ id: String, pageNum: Int, completionHandler: @escaping (JcRequestResponse<JcAlarm>) -> Void) -> URLSessionDataTask {
        
        return super._get(resourcePath: args(id: id, pageNum: pageNum)) { (r: JcRequestResponse<Data>) in
                      
            completionHandler(JcRequestResponse<JcAlarm>(r, type: JcAlarm.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
     /**
      Retrieves a paged collection `JcPagedAlarms` of `JcAlarm` instances limited to the size of property `pageSize`.
     
     # Notes: #
      Call the function repeatedly to receive the next page if the number of alarms is the same size as the pageSize
     - parameter deviceId: the c8y id of the managed object that is to be queried
     - parameter pageNum: The page to be fetched, total pages can be found in  via the statistics property `PageStatistics` of the returned `JcPagedAlarms` object
     - parameter completionHandler: the callback to be called with the list of alarms
     - returns: task thread of http request
    */
    public func getAllForDevice(deviceId: String, pageNum: Int, completionHandler: @escaping (JcRequestResponse<JcPagedAlarms>) -> Void) -> URLSessionDataTask {
        
        return super._get(resourcePath: args(forSource: deviceId, pageNum: pageNum)) { (r: JcRequestResponse<Data>) in
                      
            completionHandler(JcRequestResponse<JcPagedAlarms>(r, type: JcPagedAlarms.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }

    /**
    Creates a new `JcAlarm` in Cumulocity
     
     - parameter alarm: The `JcAlarm` to be created in Cumulocity. id should be null
     - parameter responder: the callback to be called with the updated alarm from Cumulocity i.e. will now include c8y id
     - returns: task thread of http request
     - throws: triggered in the alarm is missing mandatory data or references an invalid managed object
    */
    public func post(_ alarm: JcAlarm, completionHandler: @escaping (JcRequestResponse<JcAlarm>) -> Void) throws -> URLSessionDataTask {

        return try super._execute(method: JcConnectionRequest.Method.POST, resourcePath: C8Y_ALARMS_API, contentType: "application/json", request: alarm) { (response) in
            
            // extract new id from response header and update alarm with it
            
            if (response.status == .SUCCESS) {
                let location: String = response.httpHeaders![JC_HEADER_LOCATION] as! String
                let id = String(location[location.index(location.lastIndex(of: "/")!, offsetBy: 1)...])

                alarm.updateId(id)
            }
            
            completionHandler(JcRequestResponse<JcAlarm>(response, content: alarm))
        }
    }
    
    private func args(id: String, pageNum: Int) -> String {
       
        return C8Y_ALARMS_API + String(format: "/%@?pageNum=%@&pageSize=%@", id, pageNum, self.pageSize)
    }
    
    private func args(forSource: String, pageNum: Int) -> String {
        
        return C8Y_ALARMS_API + String(format: "?source=%@&pageNum=%@&pageSize=%@", forSource, pageNum, self.pageSize)
    }
}
