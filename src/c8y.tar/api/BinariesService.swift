//
//  BinariesService.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 22/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_BINARIES_API = "/inventory/binaries"

/**
 Allows binary attachments to be uploaded/downloaded to c8y for `JcManagedObject`
 
Refer to the [c8y API documentation](https://cumulocity.com/guides/reference/binaries/) for more information
 */
public class JcBinariesService: JcConnectionRequest<JcCumulocityConnection> {
    
    /**
     Fetch file contents using Cumulocity internal id of the file
     
     - parameter id: internal id of the stored file
     - parameter completionHandler: the callback to be called with the given `JcMultiPartContent` or error 404 if not found
     */
    public func get(_ id: String, completionHandler: @escaping (JcMultiPartRequestResponse) -> Void) -> URLSessionDataTask {

        return super._getMultipart(resourcePath: args(id)) { (response) in
            
            let disposition: String = response.httpHeaders![JC_HEADER_CONTENT_DISPOSITION] as! String

            let name = String(disposition[disposition.index(disposition.firstIndex(of: "\"")!, offsetBy: 1)..<disposition.index(disposition.endIndex, offsetBy: -2)])

            var content = JcMultiPartContent()
            _ = content.add(name, contentType: response.content?.parts[0].contentType, content: (response.content?.parts[0].content)!)
            
            completionHandler(JcMultiPartRequestResponse(response, updatedContent: content))
        }
    }
    
    /**
     Sends the file to Cumulocity to be stored
     
     - parameter name: label of the file to be shown in Cumulocity -> Administration --> Management -> File Repository
     - parameter contentType: content type representing the type of data to be stored
     - parameter content:  ByteArray representing rawe data to be stored
     - parameter completionHandler: the callback to be called with the updated `JcMultiPartContent` including new internal c8y id
     */
    func post(name: String, contentType: String, content: Data, completionHandler: @escaping (JcMultiPartRequestResponse) -> Void) -> URLSessionDataTask {
        
        return super._execute(method: JcConnectionRequest.Method.POST, resourcePath: C8Y_BINARIES_API, request: makeRequest(name, contentType: contentType, data: content)) { (response) in

            var wrappedContent = JcMultiPartContent()

            if (response.status == .SUCCESS) {
                let location: String = response.httpHeaders![JC_HEADER_LOCATION] as! String
                let id = String(location[location.index(location.lastIndex(of: "/")!, offsetBy: 1)...])

                wrappedContent.add(withId: id, name: name, contentType: contentType, content: content)
            }
            
            completionHandler(JcMultiPartRequestResponse(response, updatedContent: wrappedContent))
        }
    }
    
    private func makeRequest(_ name: String, contentType: String, data: Data) -> JcMultiPartContent {
                
        var mp = JcMultiPartContent()
        mp.add("object", contentType: nil, content: Data("{\"name\": \"\(name)\", \"type\":\"\(contentType)\"}".utf8))
        mp.add("filesize", contentType: nil, content: Data("\(data.count)".utf8))
        mp.add("file", contentType: contentType, content: data)
        
        return mp
    }
    
    private func args(_ id: String) -> String {
        
        return String(format: "%@/%@", C8Y_BINARIES_API, id)
    }
}
