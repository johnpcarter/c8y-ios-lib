//
//  # ManagedObjectService.swift
//  Cumulocity Client Library
//
//
//  Created by John Carter on 18/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_MANAGED_OBJECTS_API = "/inventory/managedObjects"
let C8Y_MANAGED_OBJECTS_EXT_API = "/identity/externalIds"
let C8Y_MANAGED_EXTIDS_API = "/identity/globalIds"

let C8Y_TYPE_DEVICE_TYPE = "c8y_DeviceGroup"

/**
 Principal access point for all Cumulocity data represented as `ManagedObject`s such as devices and groups and implemented through the API endpoint *\/inventory/managedObjects*.

 Use this class to fetch, create, update and delete assets in c8y
 
 Refer to the [c8y API documentation](https://cumulocity.com/guides/reference/inventory/) for more information
 
 */
public class JcManagedObjectsService: JcConnectionRequest<JcCumulocityConnection> {
    
    public enum ManagedObjectNotFoundError: Error {
        case id (String)
        case externalId (String)
        case type (String)
    }
    
    /**
     Used when fetching `JcManagedObject`s to determines the maximum number allowed in a single request,
     default is 50
     
    # Notes: #
     
     Managed Objects are grouped into pages  via the `JcPagedManagedObjects` class, successive pages can be fetched by
     invoking the appropriate get method with the specified page number.
     The `JcPagedManagedObjects` references the current page, size and total via the property `statistics`, which is
     defined by `JcPageStatistics`.
     */
    public var pageSize: Int = 50
    
    /**
    Fetch the managed object `JcManagedObject` using the cumulocity internal id
     
     # Notes: #
     
     The id is only known by c8y, you will need to first fetch a list of managed objects or reference the managed
     object via an external id.
     
     # Example: #
     ```
     JcPagedManagedObjectsService(conn).get(pageNum: 0) { (response) in
     
        if (response.status == .SUCCESS) {
            print("\(String(describing: response.content!.owner))")
        }
     }
     ```
     
     - parameter id: c8y generated id
     - parameter completionHandler: Callback to be called with resulting `JcManagedObject`
     - returns: task thread of http request
     - throws: No managed object found for given reference and type
     */
    public func get(_ id: String, completionHandler: @escaping (JcRequestResponse<JcManagedObject>) -> Void) -> URLSessionDataTask {
           
        return super._get(resourcePath: args(id: id)) { (r: JcRequestResponse<Data>) in
               
            completionHandler(JcRequestResponse<JcManagedObject>(r, type: JcManagedObject.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }

    /**
     Fetch the managed object `JcManagedObject` using an external id
     
    # Notes: #
     The object must have the external registered via the method `post(object:withExternalId:ofType:completionHandler:)`.
     The values will show under the identity tab of the given device in c8y Device Management
     
     - parameter forExternalId: id given by device such as serial number, imei etc.
     - parameter ofType: identifies the type of id e.g. 'c8y_Serial' or 'LoRa EUI' etc.
     - parameter completionHandler: Callback to called with resulting managed object `JcManagedObject`
     - returns: task thread of http request
     - throws: No managed object found for given reference and type
     */
    public func get(forExternalId: String, ofType: String, completionHandler: @escaping (JcRequestResponse<JcManagedObject>) -> Void) -> URLSessionDataTask {
           
        return super._get(resourcePath: args(forExternalId: forExternalId, ofType: ofType)) { (r: JcRequestResponse<Data>) in
               
            if (r.status == .SUCCESS) {
                
                do {
                    let decoder = JSONDecoder()
                    let ext: JcExternalId = try decoder.decode(JcExternalId.self, from: r.content!)
                    
                    // now we have internal reference, look for managed object
                    
                    _ = self.get(ext.id!) { (response) in
                        completionHandler(response)
                    }
                } catch {
                    // couldn't translate xref response
                    completionHandler(JcRequestResponse(r, error: ManagedObjectNotFoundError.externalId(forExternalId)))
                }
            } else {
                completionHandler(JcRequestResponse(r, error: ManagedObjectNotFoundError.externalId(forExternalId)))
            }
        }
    }

    
    /**
     Returns all managed objects in c8y restricted to the given page with the page size specified by the *pageSize*
     property of your `JcPagedManagedObjectsService` instance, default is 50 items per page.
     
     # Notes: #
     
     Invoke this method for successive page whilst incrementing the pageNum
     You will get a empty list once you go past the last page.
     
     # Example #
     ```
     let service = JcPagedManagedObjectsService(conn)
     service.pageSize = 10
     
     service.get(pageNum: 0) { (response) in
     
        if (response.status == .SUCCESS) {
            
            print("page \(response.content!.statistics.currentPage) of \(response.content!.statistics.totalPages), size \(response.content!.statistics.pageSize)")
            
            for object in response.content!.objects {
                print("\(String(describing: object.id))")
            }
        }
     }
     ```
     
     - parameter pageNum: The page to be fetched, total pages can be found in  via the statistics property `PageStatistics` of the returned `JcPageManagedObjects` object
     - parameter completionHandler: The callback to be invoked for the results, content will be an object containing a list of `JcPagedManagedObjects` labelled as objects
     - returns: Task representing http request, allows caller to cancel if required
     */
    public func get(pageNum: Int, completionHandler: @escaping (JcRequestResponse<JcPagedManagedObjects>) -> Void) -> URLSessionDataTask {
        
        return super._get(resourcePath: args(page: pageNum, ofPageSize: pageSize)) { (r: JcRequestResponse<Data>) in
            
            completionHandler(JcRequestResponse<JcPagedManagedObjects>(r, type: JcPagedManagedObjects.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
    /**
     Returns all managed objects in c8y restricted for the given type and page number with the page size specified by the *pageSize*
     property of your `JcManagedObjectService` instance, default is 50 items per page
     
     # Notes: #
         
         Invoke this method for successive page whilst incrementing the pageNum
         You will get a empty list once you go past the last page.
     
     - parameter forType: Identifies the type of managed objects to be fetched e.g. c8y_Device or c8y_Group
     - parameter pageNum: The page to be fetched, total pages can be found in  via the statistics property `PageStatistics` of the returned `JcPageManagedObjects` object
     - parameter completionHandler: The callback to be invoked for the results, content will be an object containing a list of `JcPagedManagedObjects` labelled as objects
     - returns: Task representing http request, allows caller to cancel if required
     */
    public func get(forType: String, pageNum: Int, completionHandler: @escaping (JcRequestResponse<JcPagedManagedObjects>) -> Void) -> URLSessionDataTask {
        
        return super._get(resourcePath: args(forType: forType, andPage: pageNum, ofPageSize: pageSize)) { (r: JcRequestResponse<Data>) in
            
            completionHandler(JcRequestResponse<JcPagedManagedObjects>(r, type: JcPagedManagedObjects.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
    /**
     Allows managed objects to be fetched based on set of query parameters `JcManagedObjectQuery` and grouped into pages via `JcPagedManagedObjects`
     
     # Notes: #
     
        All queries must apply (ANDED) if more than query is specified.
     
     # Example: #
     ```
     let query = JcManagedObjectQuery()
                .add("type", JcManagedObjectQuery.Operator.eq, "c8y_DeviceGroup")
                .add("bygroupid", nil, "123456")
     
     let service = JcPagedManagedObjectsService(conn).get(forQuery: query, pageNum: 0) { (response) in
     
        if (response.status == .SUCCESS) {
            
            print("page \(response.content!.statistics.currentPage) of \(response.content!.statistics.totalPages), size \(response.content!.statistics.pageSize)")
            
            for object in response.content!.objects {
                print("\(String(describing: object.id))")
            }
        }
     }
     ```
     
     - parameter forQuery: Query object referencing one or more queries to filter on
     - parameter pageNum: The page to be fetched, total pages can be found in  via the statistics property `PageStatistics` of the returned `JcPageManagedObjects` object
     - parameter completionHandler: The callback to be invoked for the results, content will be an object containing a list of `JcPagedManagedObjects` labelled as objects
     - returns: Task representing http request, allows caller to cancel if required
     */
    public func get(forQuery: JcManagedObjectQuery, pageNum: Int, completionHandler: @escaping (JcRequestResponse<JcPagedManagedObjects>) -> Void) -> URLSessionDataTask {
        
        return super._get(resourcePath: args(forQuery: forQuery, andPage: pageNum, ofPageSize: pageSize)) { (r: JcRequestResponse<Data>) in
            
            completionHandler(JcRequestResponse<JcPagedManagedObjects>(r, type: JcPagedManagedObjects.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
    /**
     Saves the managed object to your cumulocity tenant. The internal id generated by Cumulocity will
     added to the managed object reference, which will be returned in the callback function.
     
     # Notes: #
     
     Not all elements of your managed object can be posted, refer to the *REST API Guide* - (https://cumulocity.com/guides/reference/inventory/#managed-object)
     for more details
        
     - parameter object:  a `ManagedObject` created locally for which the id attribute will be null
     - parameter completionHandler: callback function which will receive the `RequestResponder<JcManagedObject>` confirming success or failure and including the
     updated managed object
     - returns: Task representing http request, allows caller to cancel if required
     - throws: Error if the object is missing required fields
     */
    public func post(_ object: JcManagedObject, completionHandler: @escaping (JcRequestResponse<JcManagedObject>) -> Void) throws -> URLSessionDataTask {
    
        return try super._execute(method: JcConnectionRequest.Method.POST, resourcePath: C8Y_MANAGED_OBJECTS_API, contentType: "application/json", request: object) { (response) in
            
            let location: String = response.httpHeaders![JC_HEADER_LOCATION] as! String
            let id = String(location[location.index(location.lastIndex(of: "/")!, offsetBy: 1)...])

            object.updateId(id)
            
            completionHandler(JcRequestResponse<JcManagedObject>(response, content: object))
        }
    }
    
    /**
    Saves the managed object to your cumulocity tenant, incuding a reference to the external id provided here. The internal id generated by Cumulocity will
    added to the managed object reference, which will be returned in the callback function.
    
    # Notes: #
    
     You can in turn fetch the managed object using the external id
     
     Not all elements of your managed object can be updated in c8y, refer to the [REST API Guide](https://cumulocity.com/guides/reference/inventory/#managed-object)
     for more details
                
    - parameter object:  a `ManagedObject` created locally for which the id attribute will be null
    - parameter withExternalId: The external id to be associated with the existing managed object
    - parameter ofType: Label identifying the type of external id e.g. 'c8y_Serial', 'LoRaDevEUI' etc.
    - parameter completionHandler: callback function which will receive the `RequestResponder<JcManagedObject>` confirming success or failure and including the
    updated managed object
    - returns: Task representing http request, allows caller to cancel if required
    - throws: Error if the object is missing required fields
    - requires: valid ManagedObject reference without id
    - seeAlso: get(forExternalId:ofType:completionHandler)
    */
    public func post(_ object: JcManagedObject, withExternalId: String, ofType: String, completionHandler: @escaping (JcRequestResponse<JcManagedObject>) -> Void) throws -> URLSessionDataTask {
    
        return try super._execute(method: JcConnectionRequest.Method.POST, resourcePath: C8Y_MANAGED_OBJECTS_API, contentType: "application/json", request: object) { (response) in
            
            if (response.status == .SUCCESS) {
             
                let location: String = response.httpHeaders![JC_HEADER_LOCATION] as! String
                let id = String(location[location.index(location.lastIndex(of: "/")!, offsetBy: 1)...])

                object.updateId(id)
                
                let r = JcRequestResponse<JcManagedObject>(response, content: object)
                
                // now register external id
                do {
                    _ = try self.register(externalId: withExternalId, ofType: ofType, forId: r.content!.id!) { (extResponse) in
                        r.update(extResponse)
                        completionHandler(r)
                    }
                } catch {
                    r.update(error)
                    completionHandler(r)
                }
            } else {
               completionHandler(JcRequestResponse<JcManagedObject>(response, type: JcManagedObject.self, dateFormatter: JcManagedObject.dateFormatter()))
            }
        }
    }
    
    /**
     Ensures a `JcManagedObject` can be retrieved with the given external id
     
     - parameter externalId: The external id to be associated with the existing managed object
     - parameter ofType: Label identifying the type of external id e.g. 'c8y_Serial', 'LoRaDevEUI' etc.
     - parameter forId: internal c8y id of the managed object
     - returns: Task representing http request, allows caller to cancel if required
     - throws: Managed Object doesn't exist for given id
     */
    func register(externalId: String, ofType: String, forId: String, completionHandler: @escaping (JcRequestResponse<Bool>) -> Void) throws -> URLSessionDataTask {
        
        let externalIdRef = JcExternalId(withExternalId: externalId, ofType: ofType)
                           
        return try super._execute(method: JcConnectionRequest.Method.POST, resourcePath: String(format: "%@/%@/externalIds", C8Y_MANAGED_EXTIDS_API, forId), contentType: "application/json", request: externalIdRef) { (response) in
                    
            completionHandler(JcRequestResponse<Bool>(response, content: response.status == .SUCCESS))
        }
    }
    
    /**
     Retrieves the list of external id's associated for the `JcManagedObject` for the given c8y internal id
     
     # Notes: #
     
     Define an external id for your managed object at creation time using the method `post(object:withExternalId:ofType:completionHandler)`
     Alternatively you can register as many external id's as you want after the object has been created using `register(externalId:ofType:forId:)`
     
     - parameter id: The internal c8y id of the `JcManagedObject`
     - parameter completionHandler: callback function which will receive the `RequestResponder<JcExternalIds>`
     */
    func externalIDsForManagedObject(_ id: String, completionHandler: @escaping (JcRequestResponse<JcExternalIds>) -> Void) -> URLSessionDataTask {

        return super._get(resourcePath: String(format: "/%@/%@/externalIds", C8Y_MANAGED_EXTIDS_API, id)) { (response) in
            completionHandler(JcRequestResponse<JcExternalIds>(response, type: JcExternalIds.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
    /**
      Updates the existing managed object. The id attribute must be provided in advance, it is
      recommended that you only use this method with a managed object that was returned by the
      aforementioned [add] method, [get] or query methods provided by the [ManagedObjectsService] class.
     
      # Note: #
     
      Not all elements of your managed object can be posted, refer to the *REST API Guide* (https://cumulocity.com/guides/reference/inventory/#managed-object)
      for more details
     - parameter object: A `ManagedObject` with a valid c8y internal id attribute
     - parameter completionHandler: Callback function which will receive the `RequestResponder<JcManagedObject>` confirming success or failure and including the
     updated managed object
     - throws: Error if the object is missing required fields
     - requires: the ManagedObject object must already exist in c8y
     */
    func update(_ object: JcManagedObject, completionHandler: @escaping (JcRequestResponse<JcManagedObject>) -> Void) throws -> URLSessionDataTask {
        
        return try super._execute(method: JcConnectionRequest.Method.POST, resourcePath: C8Y_MANAGED_OBJECTS_API, contentType: "application/json", request: object) { (response) in
       
            completionHandler(JcRequestResponse<JcManagedObject>(response, content: object))
        }
    }

    /**
     Associates the given managed object withe the other. This is most often used to add
     a device 'c8y_Device' to a group 'c8y_DeviceGroup'
     
     - parameter child: The internal id of the managed object to be assigned
     - parameter parentId: The internal id of parent managed object to which the child will be associated
     - parameter completionHandler: Callback function which will receive the `RequestResponder<JcManagedObject>` confirming success or failure
     - throws: If either the child id or parent id do not reference valid objects in c8y
     */
    func assignToGroup(child: String, parentId: String, completionHandler: @escaping (JcRequestResponse<Bool>) -> Void) throws -> URLSessionDataTask {

        let payload = "{\n" +
        "    \"managedObject\" : {\n" +
        "        \"id\" : \"\(child)\"\n" +
        "    }\n" +
        "}"
        
        return super._execute(method: Method.POST, resourcePath: String(format: "%@/%@/childAssets", C8Y_MANAGED_OBJECTS_API, parentId), contentType: "application/json", request: Data(payload.utf8)) { (response) in
            completionHandler(JcRequestResponse<Bool>(response, content: response.status == .SUCCESS))
        }
    }

    /**
     Deletes the given managed object
     
     - parameter object: a `ManagedObject` for which the c8y id attribute IS NOT null
     - parameter completionHandler: Callback function which will receive the `RequestResponder<Bool>` confirming success or failure
     */
    func delete(object: JcManagedObject, completionHandler: @escaping (JcRequestResponse<Bool>) -> Void) throws -> URLSessionDataTask {

        super._delete(resourcePath: args(id: object.id!)) { (response) in
            completionHandler(JcRequestResponse<Bool>(response, content: response.status == .SUCCESS))
        }
    }
    
    private func args(id: String) -> String {
       
        return C8Y_MANAGED_OBJECTS_API + String(format: "/%@", id)
    }
    
    private func args(forExternalId: String, ofType: String) -> String {
    
        return String(format: "%@/%@/%@", C8Y_MANAGED_OBJECTS_EXT_API, ofType, forExternalId)
    }
    
    private func args(forQuery: JcManagedObjectQuery, andPage: Int, ofPageSize: Int) -> String {
    
        return C8Y_MANAGED_OBJECTS_API + String(format: "?pageNum=%d&pageSize=%d&query=%@", andPage, ofPageSize, forQuery.build())
    }
    
    private func args(forType: String, andPage: Int, ofPageSize: Int) -> String {
    
        return C8Y_MANAGED_OBJECTS_API + String(format: "?pageNum=%d&pageSize=%d&type=%@", andPage, ofPageSize, forType)
    }
    
    private func args(page: Int, ofPageSize: Int) -> String {
        
        return C8Y_MANAGED_OBJECTS_API + String(format: "?pageNum=%d&pageSize=%d", page, ofPageSize)
    }
}
