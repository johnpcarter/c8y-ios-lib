//
//  EventsService.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 22/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_EVENTS_API = "/event/events"

/**
 Allows events related to `JcManagedObject` to fetched and posted to Cumulocity
 
Refer to the [c8y API documentation](https://cumulocity.com/guides/reference/events/) for more information
 */
public class JcEventsService: JcConnectionRequest<JcCumulocityConnection> {

    /**
     Used when fetching `JcEvent`s to determines the maximum number allowed in a single request,
     default is 50
     */
    public var pageSize: Int = 50
 
    /**
     Determines in which order events  should be fetched, i.e. most recent first (false) or oldest first (true)
     default is false, newest first
     */
    var revert: Bool = false
    
    /**
     Retrieves the  `JcEvent` details for the given c8y internal id
  
     - parameter id: c8y generated id
     - parameter completionHandler: the callback to be called with the given `JcEvent` or error 404 if not found
     - returns: task thread of http request
     */
    public func get(_ id: String, completionHandler: @escaping (JcRequestResponse<JcEvent>) -> Void) -> URLSessionDataTask {
     
        return super._get(resourcePath: self.args(id: id)) { (response: JcRequestResponse<Data>) in
                   
            completionHandler(JcRequestResponse<JcEvent>(response, type: JcEvent.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
    /**
     Retrieves all events  associated with the given source `JcManagedObject`
     
     # Notes: #
     
     It retreives the newest to oldest events first with a maximum number specified by `pageSize` in a single request. Call the method incrementing the page
     number to fetch older and older events if required.
     
     - parameter source: internal c8y of the associated managed object
     - parameter pageNum: The page to be fetched, total pages can be found in  via the statistics property `PageStatistics` of the returned `JcPagedAlarms` object
     - parameter completionHandler: the callback to be called with the given `JcPagedEvents` instance
     - returns: task thread of http request
     */
    public func get(source: String, pageNum: Int, completionHandler: @escaping (JcRequestResponse<JcPagedEvents>) -> Void) -> URLSessionDataTask {
     
        return super._get(resourcePath: self.args(forSource: source, pageNum: pageNum)) { (response: JcRequestResponse<Data>) in
                   
            completionHandler(JcRequestResponse<JcPagedEvents>(response, type: JcPagedEvents.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
    
    /**
     Submits the `JcEvent` to cumulocity for processing
    - parameter event: A new event to be posted, c8y id must be null
    - parameter completionHandler: the callback to be called with the updated `JcEvent` inclduing its internal c8y internal id
    - returns: task thread of http request
    - throws: `JcEvent` is invalid or associated `JcManagedObject` does not exist in c8y
     */
    func post(_ event: JcEvent, completionHandler: @escaping (JcRequestResponse<JcEvent>) -> Void) throws -> URLSessionDataTask {

        try super._execute(method: Method.POST, resourcePath: C8Y_EVENTS_API, contentType: "application/json", request: event) { (response) in
            
            // extract new id from response header and update event with it
                       
            if (response.status == .SUCCESS) {
                let location: String = response.httpHeaders![JC_HEADER_LOCATION] as! String
                let id = String(location[location.index(location.lastIndex(of: "/")!, offsetBy: 1)...])

                event.updateId(id)
            }
        
            completionHandler(JcRequestResponse<JcEvent>(response, content: event))
        }
    }
    
    private func args(id: String) -> String {
        
        return String(format: "%@/%@", C8Y_EVENTS_API, id)
    }
    
    private func args(forSource: String, pageNum: Int) -> String {
        return "\(C8Y_EVENTS_API)?source=\(forSource)&pageSize=\(pageSize)&pageNum=\(pageNum)&revert=\(revert)"
    }
}
