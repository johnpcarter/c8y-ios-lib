//
//  Operation.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 22/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_OPERATIONS_API = "/devicecontrol/operations/"

/**
 Allows devices to be remote controled via c8y
 
Refer to the [c8y API documentation](https://cumulocity.com/guides/reference/device-control/#device-control-api) for more information
 */
public class JcOperationService: JcConnectionRequest<JcCumulocityConnection> {
    
    /**
     Submits an operation to Cumulocity to be run on the targeted device refereneced by the managed object
     
     - parameter operation : `JcOperation` to be posted to Cumulocity
     - parameter version: The version of the operation to be rerenced
     - parameter completionHandler: callback function which will be called with the updated c8y internal id
     - throws: If operation is not correctly formatted or references non existent device in c8y
     */
    func post(operation: JcOperation, version: Double, completionHandler: @escaping (JcRequestResponse<JcOperation>) -> Void) throws -> URLSessionDataTask  {

        return try super._execute(method: Method.POST, resourcePath: C8Y_OPERATIONS_API, contentType: "application/vnd.com.nsn.cumulocity.operation+json;ver=\(version)", request: operation) { (response) in
            
            completionHandler(JcRequestResponse<JcOperation>(response, type: JcOperation.self, dateFormatter: JcManagedObject.dateFormatter()))
        }
    }
}
