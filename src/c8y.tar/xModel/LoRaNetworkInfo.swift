//
//  LoRaNetworkInfo.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 17/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let CY_LORA_NETWORK = "cylora-network"

let CY_LORA_NETWORK_LNS_TYPE = "type"
let CY_LORA_NETWORK_LNS_PROPERTIES = "properties"
let CY_LORA_NETWORK_LNS_PROPERTIES_APIKEY = "apikey"
let CY_LORA_NETWORK_LNS_PROPERTIES_ID = "id"
let CY_LORA_NETWORK_LNS_PROPERTIES_USER = "user"
let CY_LORA_NETWORK_LNS_PROPERTIES_PASSWORD = "password"

class JcLoRaNetworkInfoAssetDecoder: JcCustomAssetDecoder {
    
    static func register() {
        JcCustomAssetProcessor.registerCustomPropertyClass(property: CY_LORA_NETWORK, decoder: JcLoRaNetworkInfoAssetDecoder())
    }
    
    override func make(key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> JcLoRaNetworkInfo {
       try container.decode(JcLoRaNetworkInfo.self, forKey: key)
    }
}

public class JcLoRaNetworkInfo: JcCustomAsset {
    
    public  let type: String
    
    public let id: String
    public let apiKey: String
    public let user: String
    public let password: String
    
    enum CodingKeys: String, CodingKey {
        case type
        case properties // <-- NEW
      }

    enum propertiesCodingKeys: String, CodingKey {
        case id
        case apikey
        case user
        case password
    }
    
    required init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        self.type = try container.decode(String.self, forKey: .type)
        
        let nestedContainer = try container.nestedContainer(keyedBy: propertiesCodingKeys.self, forKey: .properties)
        self.id = try nestedContainer.decode(String.self, forKey: .id)
        self.apiKey = try nestedContainer.decode(String.self, forKey: .apikey)
        self.user = try nestedContainer.decode(String.self, forKey: .user)
        self.password = try nestedContainer.decode(String.self, forKey: .password)
    
        super.init()
    }
    
    public override func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encode(self.type, forKey: .type)
        
        var props = container.nestedContainer(keyedBy: propertiesCodingKeys.self, forKey: .properties)
        try props.encode(self.id, forKey: .id)
        try props.encode(self.apiKey, forKey: .apikey)
        try props.encode(self.user, forKey: .user)
        try props.encode(self.password, forKey: .password)
    }
}
    
