//
//  CustomAsset.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 18/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

public class JcCustomAssetDecoder {
    
    func make() throws -> JcCustomAsset {
       
        throw JcCustomAssetProcessor.EncoderNotImplementedError.key(String(describing: self))
    }
    
    func make(key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> JcCustomAsset {
       
        throw JcCustomAssetProcessor.DecoderNotImplementedError.key(String(describing: self))
    }
}

public class JcCustomAsset: Codable {
    
    /**
     * Optional 
     */
    func decode(_ container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> Void {
    }
    
    func encode(_ container: KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey> {
        return container
    }
}

class JcStringWrapper: JcCustomAsset {
    var value: String
    
    init(_ value: String) {
       self.value = value

        super.init()
    }
    
    required init(from decoder: Decoder) throws {
        fatalError("init(from:) has not been implemented")
    }
    
    override func encode(_ container: KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey> {

        var copy = container
        try copy.encode(self.value, forKey: forKey)
        
        return copy
    }
}
