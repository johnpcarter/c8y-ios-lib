//
//  LoRaDeviceInfo.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 17/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

//
//  LoRaNetworkInfo.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 17/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let CY_LORA_DEVICE = "cylora-device"

let CY_LORA_DEVICE_APP_KEY = "appKey"
let CY_LORA_DEVICE_APP_EUI = "appEUI"

let CY_LORA_DEVICE_CODEC = "lora_codec_DeviceCodecRepresentation"
let CY_LORA_DEVICE_CODEC_NAME = "name"
let CY_LORA_DEVICE_CODEC_ID = "id"

class JcLoRaDeviceInfoAssetDecoder: JcCustomAssetDecoder {
    
    static func register() {
        JcCustomAssetProcessor.registerCustomPropertyClass(property: CY_LORA_DEVICE, decoder: JcLoRaDeviceInfoAssetDecoder())
    }
    
    override func make(key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> JcLoRaDeviceInfo {
       try container.decode(JcLoRaDeviceInfo.self, forKey: key)
    }
}

public class JcLoRaDeviceInfo: JcCustomAsset {
    
    public let appKey: String
    public let appEUI: String
    
    public let codecName: String
    public let codecId: String
    
    enum CodingKeys: String, CodingKey {
        case appKey
        case appEUI
        case codec = "lora_codec_DeviceCodecRepresentation"
      }

    enum propertiesCodingKeys: String, CodingKey {
        case id
        case name
    }
    
    required init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        self.appKey = try container.decode(String.self, forKey: .appKey)
        self.appEUI = try container.decode(String.self, forKey: .appEUI)

        let nestedContainer = try container.nestedContainer(keyedBy: propertiesCodingKeys.self, forKey: .codec)
        self.codecId = try nestedContainer.decode(String.self, forKey: .id)
        self.codecName = try nestedContainer.decode(String.self, forKey: .name)
      
        super.init()
    }
    
    public override func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encode(self.appKey, forKey: .appKey)
        try container.encode(self.appEUI, forKey: .appEUI)

        var props = container.nestedContainer(keyedBy: propertiesCodingKeys.self, forKey: .codec)
        try props.encode(self.codecId, forKey: .id)
        try props.encode(self.codecName, forKey: .name)
    }
}
    
