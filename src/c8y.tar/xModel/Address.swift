//
//  Address.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 23/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let JC_MANAGED_OBJECT_ADDRESS = "xAddress"

class JcAddressAssetDecoder: JcCustomAssetDecoder {
    
    static func register() {
        JcCustomAssetProcessor.registerCustomPropertyClass(property: JC_MANAGED_OBJECT_ADDRESS, decoder: JcAddressAssetDecoder())
    }
    
    override func make() -> JcAddress {
            return JcAddress()
    }
    
    override func make(key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> JcAddress {
                
        return try container.decode(JcAddress.self, forKey: key)
    }
}

public class JcAddress: JcCustomAsset {
    
    public private(set) var addressSummary: String
    public private(set) var addressLine1: String?
    public private(set) var city: String?
    public private(set) var zipCode: String?
    public private(set) var country: String?
    public private(set) var phone: String?

    enum CodingKeys : String, CodingKey {
        case addressSummary = "xAddress"
        case country = "xAddressCountry"
        case phone = "xAddressPhone"
    }
    
    override init() {
        self.addressSummary = ""
        super.init()
    }
    
    required init(from decoder: Decoder) throws {
        fatalError("init(from:) has not been implemented")
    }
    
    override func encode(_ container: KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey> {

        var copy = container
        
        try copy.encode(self.addressSummary, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xAddress")!)
        
        if (self.country != nil) {
            try copy.encode(self.country, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xAddressCountry")!)
        }
        
        if (self.phone != nil) {
            try copy.encode(self.phone, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xAddressPhone")!)
        }
        
        return copy
    }
    
    override func decode(_ container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> Void {
        
        switch forKey.stringValue {
            case CodingKeys.addressSummary.stringValue:
                let addressBits = try container.decode(String.self, forKey: forKey).components(separatedBy: ",")
                self.addressLine1 = addressBits[0].trimmingCharacters(in: .whitespacesAndNewlines)
            
                if (addressBits.count > 1) {
                    self.city = addressBits[1]
                }
            
                if (addressBits.count > 2) {
                    self.city = addressBits[2]
                }
            case CodingKeys.country.stringValue:
                self.country = try container.decode(String.self, forKey: forKey)
            case CodingKeys.phone.stringValue:
                self.phone = try container.decode(String.self, forKey: forKey)
            default:
                break // do nothing
        }
    }
}
