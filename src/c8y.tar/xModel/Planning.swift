//
//  Planning.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 17/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let JC_MANAGED_OBJECT_PLANNING = "xPlanning"

class JcPlanningAssetDecoder: JcCustomAssetDecoder {
    
    static func register() {
        JcCustomAssetProcessor.registerCustomPropertyClass(property: JC_MANAGED_OBJECT_PLANNING, decoder: JcPlanningAssetDecoder())
    }
    
    override func make() -> JcPlanning {
            return JcPlanning()
    }
    
    override func make(key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> JcPlanning {
                
        return try container.decode(JcPlanning.self, forKey: key)
    }
}

public class JcPlanning: JcCustomAsset {
    
    public var isDeployed: Bool = false
    public var deployedDate: Date?
    public var planningDate: Date? = nil
    public var projectOwner: String? = nil
    public var isVerified: Bool? = false

    enum CodingKeys : String, CodingKey {
        case isDeployed = "xPlanningIsDeployed"
        case deployedDate = "xPlanningDeployedDate"
        case planningDate = "xPlanningDate"
        case projectOwner = "xPlanningProjectOwner"
        case isVerified = "xIsVerified"
    }
    
    override init() {
        super.init()
    }
    
    required init(from decoder: Decoder) throws {
        try super.init(from: decoder)
    }
    
    override func encode(_ container: KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey> {

        var copy = container
        
        if (self.isDeployed) {
            try copy.encode(self.isDeployed, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xPlanningIsDeployed")!)
        }
        
        if (self.deployedDate != nil) {
           try copy.encode(self.deployedDate, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xPlanningDeployedDate")!)
        }
        
        if (self.planningDate != nil) {
            try copy.encode(self.planningDate, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xPlanningDate")!)
        }
                
        if (self.projectOwner != nil) {
            try copy.encode(self.projectOwner, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xPlanningProjectOwner")!)
        }
        
        if (self.isVerified != nil) {
            try copy.encode(self.isVerified, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xIsVerified")!)
        }
        
        return copy
    }
    
    override func decode(_ container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> Void {
        
        switch forKey.stringValue {
            case CodingKeys.isDeployed.stringValue:
                isDeployed = try container.decode(Bool.self, forKey: forKey)
            case CodingKeys.deployedDate.stringValue:
                deployedDate = try container.decode(Date.self, forKey: forKey)
            case CodingKeys.planningDate.stringValue:
                planningDate = try translateISO8601Date(container, forKey: forKey)
            case CodingKeys.projectOwner.stringValue:
                projectOwner = try container.decode(String.self, forKey: forKey)
            case CodingKeys.isVerified.stringValue:
                isVerified = try container.decode(Bool.self, forKey: forKey)
            default:
                break // do nothing
        }
    }
    
    private func translateISO8601Date(_ container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> Date {
                        
        return ISO8601DateFormatter().date(from: try container.decode(String.self, forKey: forKey))!
    }
}
