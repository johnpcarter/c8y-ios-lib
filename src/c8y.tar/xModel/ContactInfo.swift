//
//  ContactInfo.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 17/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let JC_MANAGED_OBJECT_CONTACT = "xContact"

class JcContactInfoAssetDecoder: JcCustomAssetDecoder {
    
    static func register() {
        JcCustomAssetProcessor.registerCustomPropertyClass(property: JC_MANAGED_OBJECT_CONTACT, decoder: JcContactInfoAssetDecoder())
    }
    
    override func make() -> JcContactInfo {
        return JcContactInfo()
    }
    
    override func make(key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> JcContactInfo {
       try container.decode(JcContactInfo.self, forKey: key)
    }
}

public class JcContactInfo: JcCustomAsset {
    
    public var contact: String?
    public var contactPhone: String?
    public var contactEmail: String?
    
    enum CodingKeys : String, CodingKey {
        case contact = "xContactName"
        case contactPhone = "xContactPhone"
        case contactEmail = "xContactEmail"
    }
    
    override func encode(_ container: KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> KeyedEncodingContainer<JcCustomAssetProcessor.AssetObjectKey> {

        var copy = container
        
        if (self.contact != nil) {
            try copy.encode(self.contact, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xContactName")!)
        }
        
        if (self.contactPhone != nil) {
            try copy.encode(self.contactPhone, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xContactPhone")!)
        }
        
        if (self.contactEmail != nil) {
            try copy.encode(self.contactEmail, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "xContactEmail")!)
        }
        
        return copy
    }
    
    override func decode(_ container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>, forKey: JcCustomAssetProcessor.AssetObjectKey) throws -> Void {
   
        switch forKey.stringValue {
            case CodingKeys.contact.stringValue:
                self.contact = try container.decode(String.self, forKey: forKey)
            case CodingKeys.contactEmail.stringValue:
                self.contactEmail = try container.decode(String.self, forKey: forKey)
            case CodingKeys.contactPhone.stringValue:
                self.contactPhone = try container.decode(String.self, forKey: forKey)
            default:
                break
        }
    }
}
