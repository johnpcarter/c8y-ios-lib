//
//  Object.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 26/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

enum JcObjectCategory: String {
    case group
    case object
    case Industrial
    case School
    case Commercial
    case Office
    case Agriculture
    case Home
}

enum JcOperationLevel: String {
    case nominal // green
    case operating // ok with minor alarms
    case failing // ok with major alarms
    case error // critical alarms
    case offline // no status
    case unknown // never deployed
}
protocol JcObject: AnyObject, Identifiable {
   
    var id : String? { get }
    var name: String? { get }
    
    var category: JcCategory { get }
    var operationalLevel: JcOperationLevel { get }
    
    var hasChildren: Bool { get }
    
    /**
     Only applicable if hasChildren > 0
     */
    var onlineCount: Int { get }
    
    /**
     Only applicable if hasChildren > 0
     */
    var offlineCount: Int { get }
    
    var alarmsCount: Int { get }
    
    var primaryMeasurement: JcMeasurement.MeasurementValue { get }
}
