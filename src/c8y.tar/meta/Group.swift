//
//  Site.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 23/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_MANAGED_OBJECTS_SUBGROUP = "c8y_DeviceSubgroup"

public class JcGroup: Object {
    
    
    public var onlineCount: Int
    
    public var offlineCount: Int
    
    public var alarmsCount: Int
    
    public var primaryMeasurement: JcMeasurement.MeasurementValue
    
    var category: Category
    
    var operationalLevel: OperationLevel
    
    var hasChildren: Bool
    
    
    public var id: String? {
        get {
            return self._m.id
        }
    }
    
    public var name: String? {
        get {
            return self._m.name
        }
    }
       
    public var type: String? {
       get {
           return self._m.type
       }
    }
    
    public var position: JcManagedObject.C8y_Position? {
        get {
            return self._m.position
        }
        set(p) {
            if (p != nil) {
                self._m.updatePosition(p!)
            }
        }
    }
    
    public let info: JcGroupInfo
    
    public private(set) var childGroups: [JcGroup]?
    public private(set) var devices: [JcDevice]?

    var _m: JcManagedObject
    var _mgr: JcGroupManager
    var _flattenSubGroups: Bool = false
    
    convenience init(_ obj: JcManagedObject, mgr: JcGroupManager) {
       
        self.init(obj, mgr: mgr, flattenSubGroups: false)
    }
    
    init(_ obj: JcManagedObject, mgr: JcGroupManager, flattenSubGroups: Bool) {
            
        self._m = obj
        self._mgr = mgr
        self._flattenSubGroups = flattenSubGroups
        
        self.info = JcGroupInfo(orgName: obj.name!, subName: nil, address: obj.properties[JC_MANAGED_OBJECT_ADDRESS] as? JcAddress,
                                                                  contact: obj.properties[JC_MANAGED_OBJECT_CONTACT] as? JcContactInfo,
                                                                  planning: obj.properties[JC_MANAGED_OBJECT_PLANNING] as? JcPlanning)
        
        self.load()
    }
    
    public func addDevice(_ device: JcDevice, completionHandler: @escaping (Bool, Error?) -> Void) throws {
                
        _ = try JcManagedObjectsService(self._mgr.conn).post(device.toManagedObject()) { (response) in
            
            if (response.status == .SUCCESS) {
               self.devices!.append(device)
               
                do {
                    try device.setGroup(self) { (r, error) in
                        completionHandler(r, error)
                    }
                } catch {
                    completionHandler(false, error)
                }
            } else {
                completionHandler(false, self.makeError(response))
           }
        }
    }
    
    public func device(forId id: String) -> JcDevice? {
        
        return self.finder(id, ext: nil, ofType: nil)
    }
    
    public func device(forExternalId id: String, ofType type: String) -> JcDevice? {
     
        return self.finder(nil, ext: id, ofType: type)
    }
    
    public func commitChanges(completionHandler: @escaping (Bool, Error?) -> Void) throws {
    
        _ = try JcManagedObjectsService(self._mgr.conn).update(self._m) { (response) in
            
            completionHandler(response.status == .SUCCESS, self.makeError(response))
        }
    }
    
    func finder(_ id: String?, ext: String?, ofType type: String?) -> JcDevice? {
    
        var found: JcDevice? = nil
        
        for (device) in self.devices! {
            if ((id != nil && id! == device.id) || (ext != nil && device.match(forExternalId: ext!, type: type!))) {
                found = device
                break
            }
        }
        
        if (found == nil && self.childGroups != nil) {
            for (group) in self.childGroups! {
                found = group.finder(id, ext: ext, ofType: type)
                if (found != nil) {
                    break
                }
            }
        }
        
        return found
    }
    
    private func load() {
        
        self.devices = []
        self.childGroups = []

        self._load(self.id!, path: "", pageNum: 0)
    }
    
    private func _load(_ id: String, path: String?, pageNum: Int) {
    
        var query = JcManagedObjectQuery()
        _ = query.add(key: "bygroupid", op: nil, value: id)
              
        _ = JcManagedObjectsService(self._mgr.conn).get(forQuery: query, pageNum: 0) { (response) in
                   
            if (response.status == .SUCCESS) {
                for (m) in response.content!.objects {
                       
                    self.unwrapAsset(m, groupId: id, path: path!)
                    
                    if (response.content?.statistics != nil && (response.content?.objects.count)! > (response.content?.statistics.pageSize)!) {
                        // load next page
                                       
                        self._load(id, path: path, pageNum: pageNum+1)
                    }
                }
            } else {
                //TODO report error
            }
        }
    }
    
    private func unwrapAsset(_ m: JcManagedObject, groupId: String, path: String) {
        
        if (m.type == C8Y_MANAGED_OBJECTS_GROUP || m.type == C8Y_MANAGED_OBJECTS_SUBGROUP) {
            // scan child for devices

            if (self._flattenSubGroups) {
                self._load(m.id!, path: "\(path), \(m.name!)", pageNum: 0)
            } else {
                self.childGroups!.append(JcGroup(m, mgr: self._mgr))
                
                self._mgr.notifyGroupChanged(group: self)
            }
        } else {
            self.devices!.append(JcDevice(location: path, groupId: groupId, m: m, mgr: self._mgr))
            
            self._mgr.notifyGroupChanged(group: self)
        }
    }
    
    func makeError<T>(_ response: JcRequestResponse<T>) -> Error? {

        if (response.status != .SUCCESS) {
            if (response.httpMessage != nil) {
                return DeviceUpdateError.reason(response.httpMessage)
            } else if (response.error != nil){
                return DeviceUpdateError.reason(response.error?.localizedDescription)
            } else {
                return DeviceUpdateError.reason("undocumented")
            }
        } else {
            return nil
        }
    }

    enum DeviceUpdateError: Error {
        case reason (String?)
    }
}

public struct JcGroupInfo {
    
    let orgName: String
    let subName: String?
    
    let contractRef: String?
    
    let address: JcAddress?
    let siteOwner: JcContactInfo?
    let adminOwner: JcContactInfo?
    let planning: JcPlanning?
    
    init(orgName: String, subName: String?, address: JcAddress?, contact: JcContactInfo?, planning: JcPlanning?) {
        
        self.orgName = orgName
        self.subName = subName
        self.address = address
        self.siteOwner = contact
        self.planning = planning
        
        self.adminOwner = nil
        self.contractRef = nil
    }
}
