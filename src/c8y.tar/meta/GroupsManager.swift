//
//  SitesManager.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 23/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_MANAGED_OBJECTS_GROUP = "c8y_DeviceGroup"

/**
 
 */
public class JcGroupManager {
    
    /**
     
     */
    public var planningDate: Date? {
        get {
            return _planningDate
        }
        set(date) {
            if (_planningDate != date) {
                self._planningDate = date
                self.load()
            }
        }
    }
    
    let conn: JcCumulocityConnection
        
    public private(set) var availableGroups: [String:String] = [:]
    public private(set) var myGroups: [JcGroup] = []
    public private(set) var plannedGroups: [JcGroup] = []

    private let _flattenGroupHierachy: Bool
    private var _planningDate: Date?
    
    private var _myGroupReferences: [String]
    
    private var _notifiers: [JcGroupsManagerUpdateNotification] = []
    /**
     
     */
    public init(_ conn: JcCumulocityConnection, flattenGroupHierachy: Bool, myGroupReferences: [String]?) {
        
        self.conn = conn
        _flattenGroupHierachy = flattenGroupHierachy
        
        if (myGroupReferences != nil) {
            _myGroupReferences = myGroupReferences!
        } else {
            _myGroupReferences = []
        }
    }
    
    public func addMyGroups(groupId: String) {
           
        self._myGroupReferences.append(groupId)
        
        _ = JcManagedObjectsService(self.conn).get(groupId) { (response) in
            
            if (response.status == .SUCCESS) {
                self.addManagedObjectAsGroup(response.content!)
            }
        }
    }
    
    public func removeFromMyGroups(groupId: String) {
           
        self._myGroupReferences = self._myGroupReferences.filter() {
            $0 != groupId
        }
        
        self.myGroups = self.myGroups.filter() {
            $0.id != groupId
        }
        
        self.notifyGroupsChange()
    }
    
    public func reload() {
    
        self.load()
    }
    
    public func registerNotifier(_ n: JcGroupsManagerUpdateNotification) {
        
        self._notifiers.append(n)
    }
    
    public func unregisterNotifier(_ n: JcGroupsManagerUpdateNotification) {
        
        /*var found = -1
        for i in 1...self._notifiers.count {
            if (self._notifiers[i] == n) {
                found = i
            }
        }
        
        self._notifiers.remove(at: found)*/
    }
    
    public func lookupDevice(forId id: String, completionHandler: @escaping (JcDevice?, Error?) -> Void) {
        
        var found: JcDevice? = self.finder(id, ext: nil, ofType: nil, groups: self.myGroups)
        
        if (found == nil) {
            found = finder(id, ext: nil, ofType: nil, groups: self.plannedGroups)
        }
                
        if (found == nil) {
            
            // still no luck, lookup in c8y directly

            _ = JcManagedObjectsService(self.conn).get(id) { (response) in
                if (response.status == .SUCCESS && response.content != nil) {
                    completionHandler(JcDevice(response.content!, mgr: self), nil)
                } else if (response.httpMessage != nil) {
                    completionHandler(nil, APIAccessError.message(response.httpMessage!))
                } else {
                    completionHandler(nil, APIAccessError.message(response.error?.localizedDescription ?? "no message"))
                }
            }
        } else {
            completionHandler(found, nil)
        }
    }
    
    public func lookupDevice(forExternalId id: String, ofType type: String, completionHandler: @escaping (JcDevice?, Error?) -> Void) {
        
        var found: JcDevice? = self.finder(nil, ext: id, ofType: type, groups: self.myGroups)
        
        if (found == nil) {
            found = finder(nil, ext: id, ofType: type, groups: self.plannedGroups)
        }
                
        if (found == nil) {
            
            // still no luck, lookup in c8y directly

            _ = JcManagedObjectsService(self.conn).get(forExternalId: id, ofType: type) { (response) in
                if (response.status == .SUCCESS && response.content != nil) {
                    completionHandler(JcDevice(response.content!, mgr: self), nil)
                } else if (response.httpMessage != nil) {
                    completionHandler(nil, APIAccessError.message(response.httpMessage!))
                } else {
                    completionHandler(nil, APIAccessError.message(response.error?.localizedDescription ?? "no message"))
                }
            }
        } else {
            completionHandler(found, nil)
        }
    }

    private func finder(_ id: String?, ext: String?, ofType type: String?, groups: [JcGroup]) -> JcDevice? {
       
        var found: JcDevice? = nil
           
        for (group) in groups {
            
            found = group.finder(id, ext: ext, ofType: type)
            
            if (found != nil) {
                break
            }
        }
           
        return found
    }
    
    private func load() {
                
        self.plannedGroups = []
        self.myGroups = []
        
        self._load(0)
    }
    
    private func _load(_ pageNum: Int) {
                
        _ = JcManagedObjectsService(self.conn).get(forType: C8Y_MANAGED_OBJECTS_GROUP, pageNum: pageNum) { (response) in
            
            if (response.status == .SUCCESS) {
                self.myGroups = []
                for (m) in response.content!.objects {
                    
                    self.availableGroups[m.id!] = m.name
                    self.addManagedObjectAsGroup(m)
                }
                
                if (response.content?.statistics != nil && (response.content?.objects.count)! > (response.content?.statistics.pageSize)!) {
                    // load next page
                    
                    self._load(pageNum+1)
                }
            }
        }
    }
    
    private func addManagedObjectAsGroup(_ m: JcManagedObject) {
    
        let newGroup = JcGroup(m, mgr: self, flattenSubGroups: self._flattenGroupHierachy)
                           
       if (self.planningDate != nil && self.planningDate!.isSameDay(newGroup.info.planning?.planningDate)) {
           self.plannedGroups.append(newGroup)
       } else if (self._myGroupReferences.contains(newGroup.id!)) {
           self.myGroups.append(newGroup)
       }
                           
       self.notifyGroupsChange()
    }
    
    private func notifyGroupsChange() {
        
        for (n) in _notifiers {
            n.groupsManagerUpdateNotification(manager: self)
        }
    }
    
    func notifyGroupChanged(group: JcGroup) {
        
        for (n) in _notifiers {
            n.groupsManagerUpdateNotification(group: group)
        }
    }
    
    func notifyDeviceChanged(device: JcDevice) {
        
        for (n) in _notifiers {
            n.groupsManagerUpdateNotification(device: device)
        }
    }
    
    public enum APIAccessError: Error {
        case message (String)
    }
}

public protocol JcGroupsManagerUpdateNotification {
    
    func groupsManagerUpdateNotification(manager: JcGroupManager)
    
    func groupsManagerUpdateNotification(group: JcGroup) // optional
    func groupsManagerUpdateNotification(device: JcDevice) // optional
}

extension JcGroupsManagerUpdateNotification {
    
    func groupsManagerUpdateNotification(group: JcGroup) {
        
    }
    
    func groupsManagerUpdateNotification(device: JcDevice) {
        
    }
}
