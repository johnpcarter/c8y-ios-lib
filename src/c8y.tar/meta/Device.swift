//
//  Device.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 23/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_MANAGED_OBJECTS_ATTACHMENTS = "xAttachmentIds"

public class JcDevice: JcGroup {
    
    public enum Status: String {
        case UNDEPLOYED
        case UNKNOWN
        case ONLINE
        case ONLINE_WITH_ERRORS
        case OFFLINE
        case OFFLINE_WITH_ERRORS
        case MAINTENANCE
    }
    
    public var serialNumber: String? {
        get {
            if (self._externalIds != nil) {
            
                for x in self._externalIds! {
                    if (x.type == "c8y_Serial") {
                        return x.externalId
                    }
                }
            }
            
            return nil
        }
        set(v) {
            if (self._externalIds != nil) {
                
                if (v == nil) {
                    // remove
                    self._externalIds = self._externalIds!.filter() {
                        $0.type != "C8y_Serial"
                    }
                    
                } else {
                    for x in self._externalIds! {
                        if (x.type == "c8y_Serial") {
                            x.update(externalId: v!)
                        }
                    }
                }
            } else if (v != nil) {
                self._externalIds = [JcExternalId(withExternalId: v!, ofType: "c8y_Serial")]
            }
        }
    }
    
    public var model: String? {
        get {
            return self._m.hardware?.model
        }
    }
    
    public var revision: String? {
        get {
            return self._m.firmware?.version
        }
    }
    
    public var notes: String? {
        get {
            return self._m.notes
        }
    }
    
    public var lastUpdated: Date? {
        get {
            return self._m.lastUpdated
        }
    }
    
    public var requiredResponseInterval: Int? {
        get {
            return self._m.requiredAvailability?.responseInterval
        }
    }
    
    public var status: Status {
        get {
            if (self.requiredResponseInterval != nil && self.requiredResponseInterval == -1) {
                return .MAINTENANCE
            } else if (!self.isDeployed) {
                return .UNDEPLOYED
            } else if (self.lastUpdated == nil) {
                return .UNKNOWN
            } else if (self.alarms != nil && self.alarms!.total > 0) {
                if (self.connected) {
                    return .ONLINE_WITH_ERRORS
                } else {
                    return .OFFLINE_WITH_ERRORS
                }
            } else {
                if (self.connected) {
                    return .ONLINE
                } else {
                    return .OFFLINE
                }
            }
        }
    }
    
    public var isDeployed: Bool {
        get {
            return (self._m.properties[JC_MANAGED_OBJECT_PLANNING] as? JcPlanning)?.isDeployed ?? false
        }
        set(v) {
            var p: JcPlanning? = self._m.properties[JC_MANAGED_OBJECT_PLANNING] as? JcPlanning
                       
            if (p == nil) {
               p = JcPlanning()
                self._m.properties[JC_MANAGED_OBJECT_PLANNING] = p
            }
           
            p!.isDeployed = v
            p!.deployedDate = v ? Date() : nil
        }
    }
    
    public var connected: Bool {
        get {
            if (self._m.status != nil) {
                return self._m.connectionStatus!.status == .CONNECTED
            } else {
                return false
            }
        }
    }
    
    public var alarms: JcManagedObject.C8y_ActiveAlarmsStatus? {
        get {
            return self._m.activeAlarmsStatus
        }
    }
    
    public var dataPoints: JcDataPoints? {
        get {
            return self._m.dataPoints
        }
    }

    public var attachments: [String] = []

    private var _externalIds: [JcExternalId]?
    
    convenience init(location: String, groupId: String, m: JcManagedObject, mgr: JcGroupManager) {
        
        self.init(m, mgr: mgr)
    }
    
    init(_ m: JcManagedObject, mgr: JcGroupManager) {
        
        super.init(m, mgr: mgr, flattenSubGroups: true)
        
        if (_m.properties[C8Y_MANAGED_OBJECTS_ATTACHMENTS] != nil) {
            let subs = (_m.properties[C8Y_MANAGED_OBJECTS_ATTACHMENTS] as! JcStringWrapper).value.split(separator: ",")
            
            for s in subs {
                self.attachments.append(String(s))
            }
        }
        
        fetchExternalIds(m.id!, mgr: mgr)
    }
    
    init(withName name: String, type: String, model: String?, notes: String?, requiredResponseInterval: Int, mgr: JcGroupManager) {
    
        super.init(JcManagedObject(name: name, type: type, notes: notes, isDevice: true, requiredResponseInterval: requiredResponseInterval), mgr: mgr, flattenSubGroups: true)
    }
    
    func idForType(type: String) -> String? {

        var found: String? = nil

        if (self._externalIds != nil) {
            
            for x in self._externalIds! {
                if (x.type == type) {
                    found = x.externalId
                    break
                }
            }
        }

        return found
    }
    
    public func match(forExternalId id: String, type: String?) -> Bool {
        
        var match: Bool = false
        
        if (self._externalIds != nil) {
            for (x) in self._externalIds! {
                
                if ( (type == nil || type == x.type) && id == x.id) {
                    match = true
                    break
                }
            }
        }
        
        return match
    }
    
    private var _lastAttachment: JcMultiPartContent.ContentPart? = nil
    
    func attachmentForId(id: String, completionHandler: @escaping (JcMultiPartContent.ContentPart?) -> Void) {

        if (self._lastAttachment == nil || _lastAttachment?.id != id) {
            
            _ = JcBinariesService(self._mgr.conn).get(id) { r in

                if (r.status == .SUCCESS) {
                    self._lastAttachment = r.content!.parts[0]
                    completionHandler(self._lastAttachment)
                }
            }
        } else if (_lastAttachment != nil) {

            completionHandler(_lastAttachment)
        } else {
            completionHandler(nil)
        }
    }

    func addAttachment(filename: String, fileType: String, content: Data, completionHandler: @escaping (JcMultiPartContent.ContentPart?) -> Void) {

        _ = JcBinariesService(self._mgr.conn).post(name: filename, contentType: fileType, content: content) { r in

            if (r.status == .SUCCESS) {

                self._lastAttachment = r.content!.parts[0]
                self.attachments.append(self._lastAttachment!.id!)

                completionHandler(self._lastAttachment)
            }
        }
    }
    
    func replaceAttachment(index: Int, filename: String, fileType: String, content: Data, completionHandler: @escaping (JcMultiPartContent.ContentPart?) -> Void) {

        _ = JcBinariesService(self._mgr.conn).post(name: filename, contentType: fileType, content: content) { r in

            let oldRef = self._lastAttachment?.id
            self._lastAttachment = r.content!.parts[0]
            self.attachments = self.attachments.filter() {
                $0 != oldRef
            }
            
            completionHandler(self._lastAttachment)
        }
    }

    func setGroup(_ group: JcGroup, completionHandler: @escaping (Bool, Error?) -> Void) throws {
        
        _ = try JcManagedObjectsService(self._mgr.conn).assignToGroup(child: _m.id!, parentId: group.id!) { (response) in
            
            if (response.status == .SUCCESS) {
                completionHandler(true, nil)
            } else {
                completionHandler(false, self.makeError(response))
            }
        }
    }
    
    func toManagedObject() -> JcManagedObject {
        return _m
    }
    
    private func fetchExternalIds(_ id: String, mgr: JcGroupManager) {
     
        _ = JcManagedObjectsService(mgr.conn).externalIDsForManagedObject(self._m.id!) { (response) in
            
            if (response.status == .SUCCESS) {
                self._externalIds = response.content?.externalIds
                mgr.notifyDeviceChanged(device: self)
            }
        }
    }
}
