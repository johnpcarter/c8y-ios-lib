//
//  PagedMeasurements.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 22/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

/**
 List of paged measurements returned from `JcMeasurementsService`
 */
public class JcPagedMeasurements: JcEncodableContent {
 
    /**
     measurements for current page
     */
    let measurements: [JcMeasurement]
    
    /**
     Paging info, to show what page these results represent, refer to `JcPageStatistics`
     */
    let statistics: JcPageStatistics?
    
    enum CodingKeys : String, CodingKey {
        case  measurements
        case statistics
    }
    
    public required init(from decoder:Decoder) throws {
       
        let values = try decoder.container(keyedBy: CodingKeys.self)
       
        measurements = try values.decode([JcMeasurement].self, forKey: .measurements)
        statistics = try values.decode(JcPageStatistics.self, forKey: .statistics)
        
        super.init()
    }
 
    public init(_ measurements: [JcMeasurement]) {
    
        self.measurements = measurements
        self.statistics = nil
        
        super.init()
    }
    
    public override func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(measurements.self, forKey: .measurements)
    }
}
