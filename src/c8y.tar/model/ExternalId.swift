//
//  ExternalId.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 21/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

/**
 Wrapper for external id's that are used to reference `JcManagedObject`
 */
public class JcExternalIds: JcEncodableContent {
    
    /**
     List of external id's and their types for a `JcManagedObject`
     */
    let externalIds: [JcExternalId] = []
}

/**
 Represents an external id for a `JcManagedObject` e.g. 'c8y_Serial' or 'c8y_LoRa_DevEUI'
 */
public class JcExternalId: JcEncodableContent {
    
    /**
     Internal id of the associated Managed Object `JcManagedObject`
     */
    let id: String?
    
    /**
     Label identifying the type of external id .e.g.'c8y_Serial' or 'c8y_LoRa_DevEUI'
     */
    let type: String
    
    /**
     The external id itself
     */
    public private(set) var externalId: String
    
    enum CodingKeys : String, CodingKey {
        case type
        case externalId
        case managedObject
    }
    
    enum ManagedObjectCodingKeys : String, CodingKey {
        case id
        case ref = "self"
    }
    
    /**
     Define a new external id
     */
    public init(withExternalId: String, ofType: String) {
                
        self.id = nil
        self.type = ofType
        self.externalId = withExternalId
    
        super.init()
    }
    
    required init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)

        self.type = try container.decode(String.self, forKey: .type)
        self.externalId = try container.decode(String.self, forKey: .externalId)
        
        let nestedContainer = try container.nestedContainer(keyedBy: ManagedObjectCodingKeys.self, forKey: .managedObject)
        self.id = try nestedContainer.decode(String.self, forKey: .id)
        
        super.init()
    }
    
    func update(externalId id :String) {
        self.externalId = id
    }
    
    public override func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(type, forKey: .type)
        try container.encode(externalId, forKey: .externalId)
    }
}
