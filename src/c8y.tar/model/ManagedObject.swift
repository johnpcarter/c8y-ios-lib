//
//  ManagedObject.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 16/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

let C8Y_MANAGED_OBJECT_API = "/inventory/managedObject"

/**
Wraps a c8y ManagedObject, refer to [c8y API Reference guid](https://cumulocity.com/guides/reference/inventory/#managed-object) for more info
 
 # Notes: #
 
Represent nearly all assets that can be stored in c8y such as devices, groups etc. Can be enriched with custom attributes, incidentally these can be accessed
here through the dictionary property `properties`, keyed by the name of the attribute in c8y, but ONLY if they are prefixed with '#x#'
 
 If the custom property is not a String, then it will be flatted into constitute parts e.g.
 ```
 "c8y_LoRaDevice": {
    "id" : "1234"
    ...
 }
 ```
 
 would be accessible via
 ```
 var loRaId = obj.properties["c8y_LoRaDevice.id"]
 ```
 
 If you cannot prefix your custom property with 'x' or you don't want flattened Strings then you will need to the custom processor to identify a class of your own
 to encode/decode the custom structure, refer to `JcCustomAssetProcessor` class for more information
*/
public class JcManagedObject: JcEncodableContent {
        
    public private(set) var id: String?
    
    public var type: String = "c8y_Device"
    public var name: String?
    
    public private(set) var createdTime: Date = Date()
    public private(set) var lastUpdated: Date = Date()
    
    public private(set) var owner: String = ""

    public private(set) var status: C8y_Status?
    
    public var applicationOwner: String?
    public var applicationId: String?
    public var notes: String?
    
    public var firmware: C8y_Firmware?

    public private(set) var childDevices: ChildReferences?
    public private(set) var childAssets: ChildReferences?
    
    public private(set) var connectionStatus: C8y_Connection?
    public private(set) var availability: C8y_Availability?
    public private(set) var activeAlarmsStatus: C8y_ActiveAlarmsStatus?
    public private(set) var isDevice: C8y_IsDevice?
    
    public var requiredAvailability: C8y_RequiredAvailability?
    public var dataPoints: JcDataPoints?
    
    public private(set) var supportedOperations: [String]?
    public private(set) var position: C8y_Position?
    public private(set) var lpwanDevice: C8y_LpwanDevice?
    public private(set) var hardware: C8y_Hardware?
    
    /**
     Access custom properties through this class, only properties prefixed with 'x' or provided with a dedicated custom processor class will be available
     */
    public var properties: Dictionary<String, JcCustomAsset> = Dictionary()

    public enum C8y_Connection_Status: String, Codable {
        case DISCONNECTED
        case CONNECTED
    }
    public enum AvailabilityStatus: String, Codable {
        case ONLINE
        case OFFLINE
        case UNAVAILABLE
        case UNKNOWN
    }
    
    public struct ChildReferences: Decodable {
        
        let ref: String?
        let references: [ReferencedObject]?
        
        struct ReferencedObject: Decodable {
            
            let id: String?
            let name: String?
            let ref: String?
            
            enum WrapperKey: String, CodingKey {
                case managedObject
            }
            
            enum CodingKeys: String, CodingKey {
                case id
                case name
                case ref = "self"
            }
            
            init(from decoder: Decoder) throws {
            
                let container = try decoder.container(keyedBy: WrapperKey.self)
                let nestedContainer = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .managedObject)
                
                self.id = try nestedContainer.decode(String.self, forKey: .id)
                self.name = try nestedContainer.decode(String.self, forKey: .name)
                self.ref = try nestedContainer.decode(String.self, forKey: .ref)
            }
        }
        
        enum CodingKeys: String, CodingKey {
            case ref = "self"
            case references
        }
        
        public init(from decoder: Decoder) throws {
        
            let container = try decoder.container(keyedBy: CodingKeys.self)
            self.ref = try container.decode(String.self, forKey: .ref)
            self.references = try container.decode([ReferencedObject].self, forKey: .references)
        }
    }

    public struct C8y_Status: Decodable {
        
        let status: String
        let lastUpdated: Date?

        enum CodingKeys: String, CodingKey {
            case status
            case lastUpdated // <-- NEW
        }

        enum lastUpdatedCodingKeys: String, CodingKey {
            case date
        }
        
        enum embeddedDateCodingKeys: String, CodingKey {
            case date = "$date"
        }
        
        public init(from decoder: Decoder) throws {
            
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            self.status = try container.decode(String.self, forKey: .status)
            
            let nestedContainer = try container.nestedContainer(keyedBy: lastUpdatedCodingKeys.self, forKey: .lastUpdated)
            let nestedContainer2 = try nestedContainer.nestedContainer(keyedBy: embeddedDateCodingKeys.self, forKey: .date)
            
            if (nestedContainer2.contains(.date)) {
                self.lastUpdated = try nestedContainer2.decode(Date.self, forKey: .date)
            } else {
                self.lastUpdated = nil
            }
        }
    }
    
    public struct C8y_Availability: Decodable {
        
        let status: AvailabilityStatus
        let lastMessage: String
    }


    public struct C8y_Firmware: Codable {
        var version: String
    }

    public struct C8y_ActiveAlarmsStatus: Decodable {
        let warning: Int
        let minor: Int
        let major: Int
        let critical: Int
        
        var total: Int {
            return warning + minor + major + critical
        }
    }

    public struct C8y_IsDevice: Codable {
        
    }

    public struct C8y_RequiredAvailability: Codable {
        var responseInterval: Int
    }

    public struct C8y_Connection : Decodable {
        let status: C8y_Connection_Status
    }

    public struct C8y_Position: Codable {
        var lng: Double
        var lat: Double
        var alt: Double?
    }
   
    public struct C8y_LpwanDevice: Decodable {
        let provisioned: Bool
    }

    public struct C8y_Hardware: Codable {
        var serialNumber: String?
        var model: String?
        var supplier: String?
    }
    
    public init(name: String, type: String, notes: String?, isDevice: Bool, requiredResponseInterval: Int?) {
        
        self.name = name
        self.type = type
        self.notes = notes
        
        if (isDevice) {
            self.isDevice = C8y_IsDevice()
        }
        
        if (requiredResponseInterval != nil) {
            self.requiredAvailability = C8y_RequiredAvailability(responseInterval: requiredResponseInterval!)
        }
        
        super.init()
    }
    
    required init(from decoder: Decoder) throws {
           
        let container = try decoder.container(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self)
           
        for key in container.allKeys {
               
            switch key.stringValue {
                case "id":
                    self.id = try container.decode(String.self, forKey: key)
                case "type":
                    self.type = try container.decode(String.self, forKey: key)
                case "name":
                    self.name = try container.decode(String.self, forKey: key)
                case "createdTime":
                    self.createdTime = try container.decode(Date.self, forKey: key)
                case "lastUpdated":
                    self.lastUpdated = try container.decode(Date.self, forKey: key)
                case "owner":
                    self.owner = try container.decode(String.self, forKey: key)
                case "applicationId":
                    self.applicationId = try container.decode(String.self, forKey: key)
                case "applicationOwner":
                    self.applicationOwner = try container.decode(String.self, forKey: key)
                case "c8y_Status":
                    self.status = try container.decode(C8y_Status.self, forKey: key)
                case "c8y_Notes":
                    self.notes = try container.decode(String.self, forKey: key)
                case "c8y_Firmware":
                    self.firmware = try container.decode(C8y_Firmware.self, forKey: key)
                case "childAssets":
                    self.childAssets = try container.decode(ChildReferences.self, forKey: key)
                case "childDevices":
                    self.childDevices = try container.decode(ChildReferences.self, forKey: key)
                case "isDevice":
                    self.isDevice = try container.decode(C8y_IsDevice.self, forKey: key)
                case "c8y_Connection":
                    self.connectionStatus = try container.decode(C8y_Connection.self, forKey: key)
                case "c8y_RequiredAvailability":
                    self.requiredAvailability = try container.decode(C8y_RequiredAvailability.self, forKey: key)
                case "c8y_Position":
                    self.position = try container.decode(C8y_Position.self, forKey: key)
                case "c8y_Hardware":
                    self.hardware = try container.decode(C8y_Hardware.self, forKey: key)
                case "c8y_DataPoint":
                    self.dataPoints = try container.decode(JcDataPoints.self, forKey: key)
                case "c8y_SupportedOperations":
                    self.supportedOperations = try container.decode([String].self, forKey: key)
                default:
                    do {
                        self.properties = try JcCustomAssetProcessor.decode(key: key, container: container, propertiesHolder: self.properties)
                    } catch {
                        print("oops: \(error.localizedDescription)")
                    }
            }
        }
        
        super.init()
    }
       
    override public func encode(to encoder: Encoder) throws {
           
        var container = encoder.container(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self)
           
        try container.encode(self.type, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "type")!)
        try container.encode(self.name, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "name")!)
        
        if (self.notes != nil) {
            try container.encode(self.notes, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_Notes")!)
        }
        
        if (self.firmware != nil) {
            try container.encode(self.firmware, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_Firmware")!)
        }
        
        if (self.isDevice != nil) {
            try container.encode(self.isDevice, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_IsDevice")!)
        }
        
        if (self.requiredAvailability != nil) {
            try container.encode(self.requiredAvailability, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_RequiredAvailability")!)
        }
        
        if (self.position != nil) {
            try container.encode(self.position, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_Position")!)
        }
        
        if (self.hardware != nil) {
            try container.encode(self.hardware, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_Hardware")!)
        }
        
        if (self.dataPoints != nil) {
            try container.encode(self.dataPoints, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_DataPoint")!)
        }
        
        if (self.supportedOperations != nil) {
            try container.encode(self.supportedOperations, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "c8y_SupportedOperations")!)
        }
        
        for (k, v) in properties {
            
            // cannot serialise complex structures that have been flattened by decoder below (need to declare explicit class that case via registerCustomDecoder)
            if (!k.contains(".")) {
               container = try v.encode(container, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: k)!)
            }
        }
    }
    
    func updateId(_ id: String) {
        self.id = id
    }
    
    func updatePosition(_ pos: C8y_Position) {
        self.position = pos
    }
    
    func toJsonString() -> Data {

        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        
        return try! encoder.encode(self)
    }
    
    static func dateFormatter() -> DateFormatter {
        
        let rFC3339DateFormatter = DateFormatter()
        rFC3339DateFormatter.locale = Locale(identifier: "enUSPOSIX")
        rFC3339DateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ" // c8y = 2020-02-25T19:58:13.925Z
        rFC3339DateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        return rFC3339DateFormatter
    }
}
