//
//  Measurement.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 21/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

/**
Represents an c8y event, refer to [c8y API Reference Guide](https://cumulocity.com/guides/reference/measurements/#measurement) for more info
*/
public class JcMeasurement: Codable {
    
    private (set) var id: String?
    
    private (set) var source: String
    private (set) var type: String?
    private (set) var time: Date
    
    private (set) var measurements: Dictionary<String, [MeasurementValue]>?
    
    enum SourceCodingKeys: String, CodingKey {
        
        case id
    }
    
    public init(fromSource source: String, type: String) {
    
        self.source = source
        self.type = type
        self.time = Date()
        
        self.measurements = [:]
    }
    
    public required init(from decoder:Decoder) throws {
        
        let values = try decoder.container(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self)
        
        self.source = ""
        self.time = Date()
        self.measurements = [:]
        
        for (key) in values.allKeys {
            
            switch (key.stringValue) {
            case "id":
                self.id = try values.decode(String.self, forKey: key)
            case "time":
                self.time = try values.decode(Date.self, forKey: key)
            case "type":
                self.type = try values.decode(String.self, forKey: key)
            case "source":
                self.source = try JcMeasurement.getIdFromSourceContainer(key, container: values)
            case "self":
                break
            default:
                try addValues(key, container: values)
            }
        }
    }
    
    public func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self)

        try container.encode(self.type, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "type")!)
        try container.encode(self.time, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "time")!)
        
        var nestedContainer = container.nestedContainer(keyedBy: SourceCodingKeys.self, forKey:  JcCustomAssetProcessor.AssetObjectKey(stringValue: "source")!)
        try nestedContainer.encode(self.source, forKey: .id)
        
        if (measurements != nil) {
            for (k,l) in measurements! {
                
                var nestedContainer = container.nestedContainer(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: k)!)
                
                for (v) in l {
                    try nestedContainer.encode(v, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: v.label)!)
                }
            }
        }
    }
    
    public func addValues(_ values: [MeasurementValue], forType type: String) {
        
        self.measurements![type] = values
    }
    
    private func addValues(_ key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws {
        
        let nestedContainer = try container.nestedContainer(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self, forKey: key)
        
        var vals: [MeasurementValue] = []
        for (k) in nestedContainer.allKeys {
            vals.append(try MeasurementValue(forKey: k, inContainer: nestedContainer.nestedContainer(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self, forKey: k)))
        }
        
        measurements![key.stringValue] = vals //try container.decode(MeasurementValue.self, forKey: key)
    }
    
    private static func getIdFromSourceContainer(_ key: JcCustomAssetProcessor.AssetObjectKey, container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws -> String {
            
        return try container.nestedContainer(keyedBy: SourceCodingKeys.self, forKey: key).decode(String.self, forKey: .id)
    }
    
    func toJsonString() -> Data {

        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
           
        return try! encoder.encode(self)
    }
       
    /**
     A specific measurable value including a human readable label and unit of measure
     */
    public struct MeasurementValue: Encodable {
                
        let label: String
        let value: Double
        let unit: String
        
        enum CodingKeys: String, CodingKey {
            case value
            case unit
        }
        
        init(forKey key: JcCustomAssetProcessor.AssetObjectKey, inContainer container: KeyedDecodingContainer<JcCustomAssetProcessor.AssetObjectKey>) throws {
            
            self.label = key.stringValue
            self.value = try container.decode(Double.self, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "value")!)
            self.unit = try container.decode(String.self, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "unit")!)
        }
        
        public init(_ value: Double, unit: String, withLabel label: String) {
            
            self.label = label
            self.value = value
            self.unit = unit
        }
    }
}

