//
//  Operation.swift
//  Cumulocity Client Library
//
//  Created by John Carter on 21/04/2020.
//  Copyright © 2020 John Carter. All rights reserved.
//

import Foundation

/**
Represents an c8y operation, that can be posted to a remote device [c8y API Reference Guide](https://cumulocity.com/guides/reference/device-control/#operation) for more info
*/
public class JcOperation: JcEncodableContent {
    
    private(set) var id: String?
    private(set) var bulkOperationId: String?
    
    private(set) var deviceId: String
    private(set) var deviceExternalIDs: [JcExternalId]?
    
    private(set) var creationTime: Date?
    private(set) var status: Status?
    private(set) var failureReason: String?
    
    private(set) var type: String?
    private(set) var operationDetails: OperationDetails?
    
    enum Status: String, Codable {
        case SUCCESSFUL
        case FAILED
        case EXECUTING
        case PENDING
    }
    
    public required init(from decoder:Decoder) throws {
        
        let values = try decoder.container(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self)
        
        self.deviceId = ""
        
        for (key) in values.allKeys {
            
            switch (key.stringValue) {
            case "id":
                self.id = try values.decode(String.self, forKey: key)
            case "bulkOperationId":
                self.bulkOperationId = try values.decode(String.self, forKey: key)
            case "deviceId":
                self.deviceId = try values.decode(String.self, forKey: key)
            case "deviceExternalIDs":
                self.deviceExternalIDs = try values.decode([JcExternalId].self, forKey: key)
            case "creationTime":
                self.creationTime = try values.decode(Date.self, forKey: key)
            case "status":
                self.status = try values.decode(Status.self, forKey: key)
            case "failureReason":
                self.failureReason = try values.decode(String.self, forKey: key)
            default:
                self.type = key.stringValue
                self.operationDetails = try values.decode(OperationDetails.self, forKey: key)
            }
        }
        
        super.init()
    }
    
    public override func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: JcCustomAssetProcessor.AssetObjectKey.self)
        
        try container.encode(deviceId, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: "device")!)
        
        if (operationDetails != nil) {
            try container.encode(operationDetails!, forKey: JcCustomAssetProcessor.AssetObjectKey(stringValue: type!)!)
        }
    }
    
    struct OperationDetails: Codable {
        
        let name: String
        let parameters: Dictionary<String, String>?
    }
}
